
<div id="body_content">
<div class="container">

<div class="col-sm-9" style="padding-left:0px;">
<div class="about">
<div class="title">Price Promise </div>
<div class="sectionContent">
<ul>
<li>On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document.</li>
<li>You can use these galleries to insert tables, headers, footers, lists, cover pages, and other document building blocks.</li>
<li>When you create pictures, charts, or diagrams, they also coordinate with your current document look.</li>
<li>You can easily change the formatting of selected text in the document text by choosing a look for the selected text from the Quick Styles gallery on the Home tab.</li>
<li>You can also format text directly by using the other controls on the Home tab.</li>
<li>Most controls offer a choice of using the look from the current theme or using a format that you specify directly.</li>
<li>To change the overall look of your document, choose new Theme elements on the Page Layout tab.</li>
<li>To change the looks available in the Quick Style gallery, use the Change Current Quick Style Set command.</li>
<li>Both the Themes gallery and the Quick Styles gallery provide reset commands so that you can always restore the look of your document to the original contained in your current template.</li>
<li>On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document.</li>
<li>On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document.</li>
<li>You can use these galleries to insert tables, headers, footers, lists, cover pages, and other document building blocks.</li>
<li>When you create pictures, charts, or diagrams, they also coordinate with your current document look.</li>
<li>You can easily change the formatting of selected text in the document text by choosing a look for the selected text from the Quick Styles gallery on the Home tab.</li>
<li>You can also format text directly by using the other controls on the Home tab.</li>
<li>Most controls offer a choice of using the look from the current theme or using a format that you specify directly.</li>
<li>To change the overall look of your document, choose new Theme elements on the Page Layout tab.</li>
<li>To change the looks available in the Quick Style gallery, use the Change Current Quick Style Set command.</li>
<li>Both the Themes gallery and the Quick Styles gallery provide reset commands so that you can always restore the look of your document to the original contained in your current template.</li>
<li>On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document.</li>
<li>To change the overall look of your document, choose new Theme elements on the Page Layout tab.</li>
<li>To change the looks available in the Quick Style gallery, use the Change Current Quick Style Set command.</li>
<li>Both the Themes gallery and the Quick Styles gallery provide reset commands so that you can always restore the look of your document to the original contained in your current template.</li>
<li>On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document.</li>
<li>To change the overall look of your document, choose new Theme elements on the Page Layout tab.</li>


</ul>
</div>


</div>










</div>


<!--sidebar-->
    <div class="col-sm-3">
        <div class="left-sidebar">
    <?php include_once 'includes/atol_left.php';?>
	<?php include_once 'includes/news_letter_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/independent_reviews_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/deals_email_left.php';?>



</div>
</div>
<!--sidebar-->



</div>
</div>


