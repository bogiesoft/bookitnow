
<div id="body_content">
<div class="container">

<div class="col-sm-9" style="padding-left:0px;">
<div class="about">
<div class="title"> Winter Holidays </div>
<div class="contactform">  
      <img src="http://superescapes.co.uk/CityImages/Winterholidays.jpg" width:"750px"="" height:"250px"="" alt="Cheap Holidays">  
<p>Book your cheap holidays with superescapes and jet off this winter to the sun-kissed beaches to feel the warmth of the sun. We have fantastic all inclusive deals to some of the world's sun friendly destinations where you will find sunshine for over ten hours a day and the temperature ranges from 27&#176;-30&#176;. </p>
	

        
    </div>


</div>










</div>


<!--sidebar-->
    <div class="col-sm-3">
        <div class="left-sidebar">
      <?php include_once 'includes/atol_left.php';?>
	<?php include_once 'includes/news_letter_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/independent_reviews_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/deals_email_left.php';?>

</div>
</div>
<!--sidebar-->

</div>
</div>

