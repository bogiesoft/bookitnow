
<div id="body_content">
<div class="container">

<div class="col-sm-9" style="padding-left:0px;">
<div class="about">
<div class="title"> Cheap Holidays </div>
<div class="contactform">  
      <img src="http://superescapes.co.uk/CityImages/Cheapholidays.jpg" width:"750px"="" height:"250px"="" alt="Cheap Holidays">  
<p>At Book It Now we assure you that you will be spoilt for choice of cheap holidays, as we have loads of cheap package holidays all inclusive. We know you have been working hard and saving the whole year to make the most of your holiday enjoying it to the fullest. We have impressive cheap deals on last minute holidays, family holidays, city breaks and much more. </p>
	

        
    </div>


</div>










</div>


<!--sidebar-->
    <div class="col-sm-3">
        <div class="left-sidebar">
      <?php include_once 'includes/atol_left.php';?>
	<?php include_once 'includes/news_letter_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/independent_reviews_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/deals_email_left.php';?>



</div>
</div>
<!--sidebar-->

</div>
</div>

