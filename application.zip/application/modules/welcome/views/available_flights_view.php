<div id="top_header">
  <div  class="container">
    <div class="left"> <a href="#" class="">Price Promise</a> <a href="#">About Us</a> <a href="#">Terms of Use</a> <a href="#" target="_blank">Blog</a> </div>
  </div>
</div>
<div class="clearfix"></div>
<div id="header">
  <div class="container">
    <div class="col-sm-3">
      <div class="logo"><a href="#"><img src="/images/logo.png" class="img-responsive"></a></div>
    </div>
    <div class="col-sm-3">
      <div class="logo"><a href="#">
        <p>Book With Confidence</p>
        <img src="/images/abta.png" class="img-responsive"> </a></div>
    </div>
    <div class="col-sm-6">
      <div class="phonenumbers">
        <h2><i class="fa fa-phone"></i> 0138 629 8033</h2>
        <p>Mon-Fri: 8am - 11pm | Sat: 9am -10pm | Sun: 10am - 10pm</p>
        <p class="call">Call Our Local Rate Num :  203 598 4710 | Mon- Sat 9am - 5pm</p>
      </div>
    </div>
  </div>
</div>
<div class="clearfix"></div>
<!----<div id="menus">
  <div class="container">
    <div class="line">
      <nav class="">
        <p class="nav-text"> menu <span><i class="fa fa-bars"></i></span></p>
        <div class="top-nav s-12 l-10">
          <ul>
            <li><a title="Home" href="#"> Home</a></li>
            <li> <a title="Destinations" href="#">Destinations</a> </li>
            <li><a title=" Special Offers" href="#">Special Offers</a></li>
            <li><a title="Hotel Only" href="#">Hotel Only</a></li>
            <li> <a title="City Breaks" href="#"> City Breaks</a></li>
            <li><a title="Contact Us" href="#">Contact Us</a></li>
            <div class="view"><a href="#" title="view my booking">View My Booking</a></div>
          </ul>
        </div>
      </nav>
    </div>
  </div>
</div>
<div class="clearfix"></div>

<!-- start slider -->


   
    
    
<div id="body_content" style="margin:0px;">
<div id="your_Search">
<div class="container">
<div class="you">
<p><strong>Your Search:</strong> London Airports To Benidorm, 2 Adults, 7 Nights, 02 October 2015.</p>
</div>

 <div class="make_buttons">
    <div class="button" data-toggle="collapse" data-target="#demo" style="">Change Search</div>
  
<div class="clearfix"></div>
  
  
  <div id="demo" class="collapse" style="margin-top:1em;">
   <div class="row" class="forms">
        <form class="">
        <div class="form-group col-sm-2" >
        <label> Fly From:</label>
                    <br>
                    <select name="" onchange="" id="" class="full_width">
                          <option value="-1">Select Destination</option>
                          <option value="-1"></option>
                          <option selected="selected" value="">London Airports</option>
                          <option value="">Midlands</option>
                          <option value="">North East</option>
                          <option value="">North West</option>
                          <option value="">Scotland</option>
                          <option value="">South West</option>
                          <option value="-1">---------------------</option>
                          <option value="">Aberdeen</option>
                          <option value="">Belfast</option>
                          <option value="">Birmingham</option>
                          <option value="">Bournemouth</option>
                          <option value="">Bristol</option>
                          <option value="">Cardiff</option>
                          <option value="">Doncaster Sheffield</option>
                          <option value="">Durham Tees Valley</option>
                          <option value="">Edinburgh</option>
                          <option value="">Exeter</option>
                          <option value="">Glasgow International</option>
                          <option value="">Glasgow Prestwick</option>
                          <option value="">Humberside</option>
                          <option value="">Leeds Bradford</option>
                          <option value="">Liverpool</option>
                          <option value="">London Gatwick</option>
                          <option value="">London Heathrow</option>
                          <option value="">London Luton</option>
                          <option value="">London Stansted</option>
                          <option value="">London Southend</option>
                          <option value="">Manchester</option>
                          <option value="">Newcastle</option>
                          <option value="">Norwich</option>
                          <option value="">Nottingham East Midlands</option>
                        </select>
                  </div>
         
        <div class="form-group col-sm-2">
            <label> Travel To:</label>
                    <br>
                    <select name="" id="" class="full_width">
                          <option value="-1">Select Destination</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;color:red;">TOP SELLING BEACH</option>
                          <option value="">Algarve</option>
                          <option selected="selected" value="ALC">Benidorm</option>
                          <option value="">Mexico - Cancun</option>
                          <option value="">Costa Brava</option>
                          <option value="">Cyprus</option>
                          <option value="">Dubai</option>
                          <option value="">Florida - Sanford</option>
                          <option value="">Fuerteventura</option>
                          <option value="">Gran Canaria</option>
                          <option value="">Ibiza</option>
                          <option value="">Lanzarote</option>
                          <option value="">Majorca / Mallorca</option>
                          <option value="">Sharm El Sheikh</option>
                          <option value="">Tenerife</option>
                          <option value="">Turkey - Dalaman</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;color:red;">TOP SELLING CITY</option>
                          <option value="">Amsterdam</option>
                          <option value="">Barcelona</option>
                          <option value="">Berlin</option>
                          <option value="">Budapest</option>
                          <option value="">Dubai</option>
                          <option value="">Krakow</option>
                          <option value="">Madrid</option>
                          <option value="">Marrekech</option>
                          <option value="">Palma City</option>
                          <option value="">Paris</option>
                          <option value="">Prague</option>
                          <option value="">Rome</option>
                          <option value="">Tallin</option>
                          <option value="">Venice</option>
                          <option value="">Vienna</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">AUSTRIA</option>
                          <option value="">Innsbruck</option>
                          <option value="">Salzburg</option>
                          <option value="">Vienna</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">BALEARICS (SEARCH ALL)</option>
                          <option value="">Majorca / Mallorca</option>
                          <option value="">Ibiza</option>
                          <option value="">Menorca</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">BULGARIA (SEARCH ALL)</option>
                          <option value="">Bourgas</option>
                          <option value="">Plovdiv</option>
                          <option value="">Sofia</option>
                          <option value="">Varna</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">CAPE VERDE</option>
                          <option value="">Boa Vista</option>
                          <option value="">Sal</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">CANADA</option>
                          <option value="">Vancover</option>
                          <option value="">Calgary</option>
                          <option value="">Toronto</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">CARIBBEAN (SEARCH ALL)</option>
                          <option value="">Antigua</option>
                          <option value="">Bahamas - Nassau</option>
                          <option value="">Barbados</option>
                          <option value="">Domincan Rep (North)</option>
                          <option value="">Domincan Rep (South)</option>
                          <option value="">Grenada</option>
                          <option value="">Jamaica</option>
                          <option value="">St Kitts</option>
                          <option value="">St Lucia</option>
                          <option value="">Tobago</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">CUBA</option>
                          <option value="">Cayo Coco</option>
                          <option value="">Holguin</option>
                          <option value="">Varadero</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">CZECH REPUBLIC</option>
                          <option value="">Prague City Break</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">CROATIA</option>
                          <option value="">Dubrovnik</option>
                          <option value="">Pula</option>
                          <option value="">Split</option>
                          <option value="">Zagreb</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">CANARY ISLANDS (SEARCH ALL)</option>
                          <option value="">Tenerife</option>
                          <option value="">Lanzarote </option>
                          <option value="">Gran Canaria</option>
                          <option value="">Fuerteventura</option>
                          <option value="">La Palma</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">CYPRUS (SEARCH ALL)</option>
                          <option value="">Larnaca</option>
                          <option value="">Paphos </option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">DENMARK</option>
                          <option value="">Copenhagen</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">DUBAI - UNITED ARAB EMIRATES</option>
                          <option value="">Dubai</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">EGYPT (SEARCH ALL)</option>
                          <option value="">Sharm El Sheikh</option>
                          <option value="">Hurghada</option>
                          <option value="">Marsa Alam</option>
                          <option value="">Taba</option>
                          <option value="">Luxor</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">ESTONIA</option>
                          <option value="">Tallinn</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">FRANCE</option>
                          <option value="">Biarritz</option>
                          <option value="">Bordeaux</option>
                          <option value="">Paris CDG</option>
                          <option value="">Grenoble</option>
                          <option value="">La Rochelle</option>
                          <option value="">Lyon</option>
                          <option value="">Montpellier</option>
                          <option value="">Marseille</option>
                          <option value="">Nice</option>
                          <option value="">Toulouse</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">FRANCE - CORSICA</option>
                          <option value="">Ajaccio</option>
                          <option value="">Bastia- corsica</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">GAMBIA</option>
                          <option value="">Gambia - Banjul</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">GERMANY</option>
                          <option value="">Berlin</option>
                          <option value="">Colgne</option>
                          <option value="">Dortmund</option>
                          <option value="">Dusseldorf</option>
                          <option value="">Hamburg</option>
                          <option value="">Munich</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">GREECE AND ISLANDS (SEARCH ALL)</option>
                          <option value="">Athens</option>
                          <option value="">Chania (Crete)</option>
                          <option value="">Corfu</option>
                          <option value="">Halkidiki</option>
                          <option value="">Heraklion (Crete)</option>
                          <option value="">Kalamata</option>
                          <option value="">Kefalonia</option>
                          <option value="">Kos</option>
                          <option value="">Lemnos</option>
                          <option value="">Mykonos</option>
                          <option value="">Prevaza / Lefkas</option>
                          <option value="">Rhodes</option>
                          <option value="">Samos</option>
                          <option value="">Santorini</option>
                          <option value="">Skiathos</option>
                          <option value="">Volos</option>
                          <option value="">Zante</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">IRELAND</option>
                          <option value="">Dublin - City Break</option>
                          <option value="">Cork - City Break</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">INDIA</option>
                          <option value="">Goa</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">INDIAN OCEAN</option>
                          <option value="">Male - Maldives</option>
                          <option value="">Mauritius</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">ISREAL</option>
                          <option value="">Tel aviv</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">ITALY</option>
                          <option value="">Bergamo - Milan</option>
                          <option value="">Bari</option>
                          <option value="">Bologna</option>
                          <option value="">Cagliari</option>
                          <option value="">Rome - Ciampino</option>
                          <option value="">Catania</option>
                          <option value="">Rome - Fiumicino</option>
                          <option value="">Florence</option>
                          <option value="">Milan Malpensa</option>
                          <option value="">Naples</option>
                          <option value="">Turin</option>
                          <option value="">Venice Treviso / Marco Polo</option>
                          <option value="">Verona</option>
                          <option value="">Pisa</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">ITALY - SARDINIA</option>
                          <option value="">Alghero - Sardinia</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">ITALY SICILY</option>
                          <option value="">Palermo - Sicily</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">JORDAN</option>
                          <option value="">Amman</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">KENYA</option>
                          <option value="">Kenya - Mombasa</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">LATVIA</option>
                          <option value="">Riga</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">MALTA</option>
                          <option value="">Malta</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">MEXICO (SEARCH ALL)</option>
                          <option value="">Cancun</option>
                          <option value="">Puerto Vallarta</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">MOROCCO (SEARCH ALL)</option>
                          <option value="">Agadir</option>
                          <option value="">Marrakech - City Break</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">NETHERLANDS</option>
                          <option value="">Amsterdam</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">PORTUGAL</option>
                          <option value="">The Algarve</option>
                          <option value="">Lisbon - Estoril Coast</option>
                          <option value="">Porto - City Break</option>
                          <option value="">Madeira</option>
                          <option value="">Porto Santo</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">SLOVAKIA</option>
                          <option value="">Bratslava</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">SLOVENIA</option>
                          <option value="">Ljubljana</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">SPAIN - MAINLAND (SEARCH ALL)</option>
                          <option value="">Benidorm / Costa Blanca</option>
                          <option value="">Costa Del Sol</option>
                          <option value="">Costa Almeria</option>
                          <option value="">Costa Brava</option>
                          <option value="">Costa Dorada / Salou</option>
                          <option value="">Costa Tropical</option>
                          <option value="">Barcelona - City Break</option>
                          <option value="">Bilbao - City Break</option>
                          <option value="">Gibraltar - City Break</option>
                          <option value="">Madrid - City Break</option>
                          <option value="">Seville - City Break</option>
                          <option value="">Valencia - City Break</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">SPAIN - BALEARICS</option>
                          <option value="">Majorca / Mallorca</option>
                          <option value="">Ibiza</option>
                          <option value="">Menorca</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">SPAIN - CANARIES</option>
                          <option value="">Tenerife</option>
                          <option value="">Lanzarote</option>
                          <option value="">Gran Canaria</option>
                          <option value="">Fuerteventura</option>
                          <option value="">La Palma</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">SWEDEN</option>
                          <option value="">Gothenburg </option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">SWITZERLAND</option>
                          <option value="">Basel</option>
                          <option value="">Geneva</option>
                          <option value="">Zurich</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">THAILAND</option>
                          <option value="">Bangkok</option>
                          <option value="">Phuket</option>
                          <option value="">Koh Samui</option>
                          <option value="">Krabi</option>
                          <option value="">Chiang Mai</option>
                          <option value="">Chiang Rai</option>
                          <option value="">Hua Hin</option>
                          <option value="">Surat Thani</option>
                          <option value="">Trat</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">TUNISIA</option>
                          <option value="">Monastir</option>
                          <option value="">Djerba</option>
                          <option value="">Enfidha</option>
                          <option value="">Tunis - City Break</option>
                          <option value="-1"> </option>
                          <option value="" style="font-weight:bold;">TURKEY (SEARCH ALL)</option>
                          <option value="">Dalaman</option>
                          <option value="">Bodrum Region</option>
                          <option value="">Antalya Region</option>
                          <option value="">Izmir</option>
                          <option value="">Istanbul Sabiha - City Break</option>
                          <option value="">Istanbul Ataturk - City Break</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">UNITED STATES OF AMERICA</option>
                          <option value="">Miami - Breaks</option>
                          <option value="">Orlando - Sanford</option>
                          <option value="">Orlando - International</option>
                          <option value="">Tampa international</option>
                          <option value="">Atlanta - City Break</option>
                          <option value="">Boston - City Break</option>
                          <option value="">Chicago O'Hare - City Break</option>
                          <option value="">Las Vegas - City Break</option>
                          <option value="">New York JFK - City Break</option>
                          <option value="">New York Newark - City Break</option>
                          <option value="">Philadelphia - City Break</option>
                          <option value="">Washinton Dullas - City Break</option>
                          <option value="">Washinton Ronald R - City Break</option>
                          <option value="-1"> </option>
                          <option value="-1" style="font-weight:bold;">UNITED ARAB EMIRATES (DUBAI)</option>
                          <option value="">Dubai</option>
                        </select>
          </div>
        <div class="form-group col-sm-2">
            <label> Departure Date:</label>
                    <br>
                    <input readonly name="" value="02/10/2015" id="" type="text">
          </div>
          
          
           <div class="form-group col-sm-2">
            <label> Nights:</label>
                    <br>
                    <select name="" id="" class="full_width">
                         
                          <option value="-1">---</option>
                          <option value="">1</option>
                          <option value="">2</option>
                          <option value="">3</option>
                          <option value="">4</option>
                          <option value="">5</option>
                          <option value="">6</option>
                          <option value="">7</option>
                          <option value="">8</option>
                          <option value="">9</option>
                          <option value="">10</option>
                          <option value="">11</option>
                          <option value="">12</option>
                          <option value="">13</option>
                          <option value="">14</option>
                          <option value="">15</option>
                          <option value="">16</option>
                          <option value="">17</option>
                          <option value="">18</option>
                          <option value="">19</option>
                          <option value="">20</option>
                          <option value="">21</option>
                          <option value="">22</option>
                          <option value="">23</option>
                          <option value="">24</option>
                          <option value="">25</option>
                          <option value="">26</option>
                          <option value="">27</option>
                          <option value="">28</option>
                          <option value="">29</option>
                          <option value="">30</option>
                          <option value="">31</option>
                          <option value="">32</option>
                          <option value="">33</option>
                          <option value="">34</option>
                          <option value="">35</option>
                          <option value="">36</option>
                          <option value="">37</option>
                          <option value="">38</option>
                          <option value="">39</option>
                          <option value="">40</option>
                          <option value="">41</option>
                          <option value="">42</option>
                          <option value="">43</option>
                          <option value="">44</option>
                          <option value="">45</option>
                          <option value="">46</option>
                          <option value="">47</option>
                          <option value="">48</option>
                          <option value="">49</option>
                          </select>
          </div>
          
       
          
       <div class="form-group col-sm-2">
       <label> Board Basis:</label>
                    <span class="txt_red">*</span><br>
                    <select name="" id="" class="full_width">
                          <option value="-1">- Please Select -</option>
                          <option selected="selected" value="AI">All Inclusive</option>
                          <option value="">Room Only</option>
                          <option value="">Bed and Breakfast</option>
                          <option value="">Self Catering</option>
                          <option value="">Half Board</option>
                          <option value="">Full Board</option>
                        </select>
       </div>
          
          
          <div class="form-group col-sm-2">
          <label> Min Rating:</label>
                    <br>
                    <select name="" id="" class="full_width">
                          <option selected="selected" value="any">Any</option>
                          <option value="">2* +</option>
                          <option value="">3* +</option>
                          <option value="">4* +</option>
                          <option value="">5* +</option>
                        </select>
          </div>
          
          <div class="form-group col-sm-2">
          <label> Rooms:</label>
                    <br>
                    <select name="" id="" class="full_width" onchange="">
                          <option selected="selected" value="1">1</option>
                          <option value="">2</option>
                          <option value="">3</option>
                        </select>
          </div>
          
          <div class="form-group col-sm-2">
          <label> Adults:</label>
                    <br>
                    <select name="" onchange="" class="full_width">
                          <option value="">1</option>
                          <option selected="selected" value="2">2</option>
                          <option value="">3</option>
                          <option value="">4</option>
                          <option value="">5</option>
                          <option value="">6</option>
                          <option value="">7</option>
                          <option value="">8</option>
                          <option value="">9</option>
                          <option value="">10</option>
                          <option value="">11</option>
                          <option value="">12</option>
                        </select>
          </div>
          
          <div class="form-group col-sm-2">
           <label> Children 2-12 yrs:</label>
                    <br>
                    <select name="" onchange="" id="" class="full_width">
                          <option selected="selected" value="0">0</option>
                          <option value="">1</option>
                          <option value="">2</option>
                          <option value="">3</option>
                          <option value="">4</option>
                          <option value="">5</option>
                          <option value="">6</option>
                          <option value="">7</option>
                          <option value="">8</option>
                          <option value="">9</option>
                        </select>
          </div>
          <div class="form-group col-sm-2">
          <label> Infants 0-1 yrs:</label>
                    <br>
                    <select name="" id="" class="full_width">
                          <option selected="selected" value="0">0</option>
                          <option value="">1</option>
                          <option value="">2</option>
                        </select>
          </div>
          <div class="button" data-toggle="collapse" style="margin-top:1.8em;">Search Again</div>
          
      </form>
      </div>
      </div>

</div>








</div>


</div>
<div class="clearfix"></div>

<div id="select_names">
<div class="container">
<!--STEPS-->
<div class="hide_mobile hide_tablet bg_grey border_b has_bottom_margin">
      <div class="gridContainer ">
    <ul class="fluidList steps fh clearfix">
          <li class="current"><strong>1. Select Flights </strong></li>
          <li class=""><strong>2. Select Hotel</strong></li>
          <li class=""><strong>3. Savings &amp; Extras</strong></li>
          <li class=""><strong>4. Book</strong></li>
          <li class="bg_1 clearfix">
        <div id="LP_DIV_1429625391320" class="right"></div>
      </li>
        </ul>
  </div>
    </div>
<!--/STEPS-->

</div>

</div>

<div class="clearfix"></div>


<div class='content' id="dvContent">
	<?php
		echo '<div id="dates_list_container">';
		foreach ($dates_list as $date){
			if($selected_date == $date)
			{
				echo '<span style="color:red" class="current">'.$date.'</span> | ';
			}else{
				echo '<span style="color:red">'.$date.'</span> | ';
			}
		}
		echo '</div>';
		echo '<table class="table table-stripped" id="flights" style="color:#3E3535">';
			echo '<tbody>';	
			//$this->cache->delete('arrivals');
			$departures = ( !$this->cache->get('departures')) ? (($this->cache->save('departures', $controller->fetch_departures(), 3600)) ? $this->cache->get('departures') : array() ) : $this->cache->get('departures');
			$arrivals = ( !$this->cache->get('arrivals')) ? (($this->cache->save('arrivals', $controller->fetch_arrivals(), 3600)) ? $this->cache->get('arrivals') : array() ) : $this->cache->get('arrivals');
			
			$count = 0;
			
			foreach($flights_list['offers_list'] as $flight_obj)
			{		
				$dscode = $flight_obj['@attributes']['depapt'];
				$ascode = $flight_obj['@attributes']['arrapt'];			
				$ascode = trim(explode('-',$arrivals[(string)$ascode])[1]);
				$dscode = trim(explode('-',$departures[(string)$dscode])[0]);
				
				echo '<tr>';
					echo '<td><div>'.$flight_obj['@attributes']['suppname'].'</div><div>'.date('l d M Y',$controller->cvtDt($flight_obj['@attributes']['outdep'])).'</div><div>'.$dscode.' to '.$ascode.'</div></td>';
					echo '<td><div>'.$flight_obj['@attributes']['suppname'].'</div><div>'.date('l d M Y',$controller->cvtDt($flight_obj['@attributes']['indep'])).'</div><div>'.$ascode.' to '.$dscode.'</div></td>';
				echo '</tr>';
				$count++;
				if($count == 10)break;
			}
			echo '</tbody>';
		echo '</table><div class="pagination"><ul style="display:inline;color:black" id="pager_list">';
		$res_count = count($flights_list['offers_list']);
		if($res_count > 10)
		{
			$num_pages = ($res_count%10)? ($res_count/10)+1 : $res_count/10; 
			for($i=1;$i<=$num_pages;$i++)
			{
				if($i==1)echo '<li class="page_active"><a>'.$i.'</a></li>';
				else echo '<li><a>'.$i.'</a></li>';
			}			
		}
		echo '</ul></div>';
	?>
	
	<!-- pagination <div id="example"></div> --> 
</div>


<div class="clearfix"></div>
<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-4">
				<div class="top_beach">
					<h2>On This Site</h2>
					<ul>
						<li><a href="#">Book A Holiday</a></li>
						<li><a href="#">Special Offers</a></li>
						<li><a href="#">Hotel Only</a></li>
						<li><a href="#">City Breaks</a></li>
						<li><a href="#">Insurance</a></li>
						<li><a href="#">Deals By Email</a></li>					
					</ul>
					<ul class="second">
						<li><a href="#">About Us</a></li>
						<li><a href="#">Contact Us</a></li>
						<li><a href="#">Terms And Conditions</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Website Terms Of Use</a></li>
					</ul>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="top_beach">
					<h2>Top Beach Holidays</h2>
					<ul>
						<li><a href="#">The Algarve</a></li>
						<li><a href="#">Benidorm</a></li>
						<li><a href="#">Costa Brava</a></li>
						<li><a href="#">Corfu</a></li>
						<li><a href="#">Crete</a></li>
						<li><a href="#">Cyprus</a></li>
						<li><a href="#">Egypt</a></li>
						
					</ul>
					<ul class="third">
						<li><a href="#">Fuerteventura</a></li>
						<li><a href="#">Gran Canaria</a></li>
						<li><a href="#">Greece</a></li>
						<li><a href="#">Kos</a></li>
						<li><a href="#">Lanzarote</a></li>
						<li><a href="#">Majorca</a></li>
						<li><a href="#">Malta</a></li>
					</ul>
					<ul class="third">					
						<li><a href="#">Morocco</a></li>
						<li><a href="#">Rhodes</a></li>
						<li><a href="#">Sharm El Sheikh</a></li>
						<li><a href="#">Tenerife</a></li>
						<li><a href="#">Tunisia</a></li>
						<li><a href="#">Turkey</a></li>					
					</ul>
				</div>
			</div>
<div class="col-sm-4">
<div class="top_beach">
<h2>On This Site</h2>
<ul>
<li><a href="#">Book A Holiday</a></li>
<li><a href="#">Special Offers</a></li>
<li><a href="#">Hotel Only</a></li>
<li><a href="#">City Breaks</a></li>
<li><a href="#">Insurance</a></li>
<li><a href="#">Deals By Email</a></li>

</ul>
<ul class="four">
<li><a href="#">About Us</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Terms And Conditions</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Website Terms Of Use</a></li>


</ul>
</div>

</div>



</div>
</div>

<p class="all">All Inclusive Holidays | Adults Only Holidays | Family Holidays</p>


</div>

<div class="container">
<p class="privacy">
At Superescapes we endeavour not just to provide great value cheap holidays but also to make sure that you get your perfect dream holiday at
 the cheapest price. We offer a wide range of holidays, including cheap holidays, All Inclusive holidays, Last Minute holidays, City Breaks 
 and more. We render our dedicated services to help you find, compare and choose best cheap holiday deals and escape to your exotic holiday 
 destination.

Whether it is Majorca, Spain, Turkey, Egypt or any other favourite destination of your choice, you can search for your perfect holiday
 at Superescapes.

We assure you that your holidays are fully protected, as we are members of ABTA and ATOL, so go ahead, book with confidence, and leave all your travel worries to us.
</p>

</div>

<div id="bottom_footer">
<div class="container">
<p class="privacy" style="float:left;">� 2015 Book it now</p>
<a href="#" style="float:right;color:#6c6c6c; font-size:12px;">Powered by: Expert Web Worx</a>

</div>

</div>
<div class="top"> <a href="#" class="scrollToTop"></a> </div>


<script type="text/javascript">
	var flight_crypt = '<?php echo $this->uri->segment(2);?>';
</script>
<style>
.current{
background: gray;
}
</style>

