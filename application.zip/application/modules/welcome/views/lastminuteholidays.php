
<div id="body_content">
<div class="container">

<div class="col-sm-9" style="padding-left:0px;">
<div class="about">
<div class="title"> Last Minute Holidays </div>
<div class="contactform">  
      <img src="http://superescapes.co.uk/CityImages/Lastminuteholidays.jpg" width:"750px"="" height:"250px"="" alt="Cheap Holidays">  
<p>Snap up, a cheap last minute holiday deal at Book It Now and save on your package. If you are keen to book a last minute escape to the sunny shores then last minute package holidays all inclusive would be best bargain for you. If you are planning a family holiday, then you are at the right place. Superescapes offers extensive range of cheap late family holidays. So, pack your bags and get ready to explore the exotic holiday destinations.</p>
	

        
    </div>


</div>










</div>


<!--sidebar-->
    <div class="col-sm-3">
        <div class="left-sidebar">
      <?php include_once 'includes/atol_left.php';?>
	<?php include_once 'includes/news_letter_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/independent_reviews_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/deals_email_left.php';?>

</div>
</div>
<!--sidebar-->

</div>
</div>

