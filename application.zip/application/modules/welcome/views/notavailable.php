<style>
.text-one{
color:blue;
 color: #089de3;
 font-size:15px;
}
.form-wrap{
padding:50px;

}
.click{
color:#094fa3;
font-size:20px;
}
.click a:hover{
color:#094fa3;
font-size:20px;
}
</style><div id="body_content">
<div class="container">
<div class="row form-wrap">
<div class="col-sm-12 col-md-12 col-xs-12" style="text-align:center">
<h3 class="title-name">We're Sorry, but we cannot find any available flights for your selected criteria.</h1>
<h4>Your Searched for: </h4>
<h5 class="text-one" id="no_res"></h5>


<h5>Need Assistance? We Can Help!</h1>
<h4>Call 0208 548 3048 To Speak to an Advisor</h4>
<h5>OR</h5>
<h4 class="click"><a href="#">Click Here To Begin a New Search</a></h4>

</div>
</div>


</div>
</div>
