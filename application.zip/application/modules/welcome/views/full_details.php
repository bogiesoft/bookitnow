


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><title>
	Home
</title>
    <!--LOAD THE MINUMUM GLOBAL JS BELOW-->
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700,900" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/css/bookitnow.min.css" rel="stylesheet" type="text/css" /> 
  	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/flexslider.css?v=1.1" />
    <script src="<?php echo base_url();?>assets/js/jquery.flexslider-min.js" type="text/javascript"></script>

<style>
.flexslider
{
margin: 10px 0 10px 0;
background: #fff;
position: relative;
-webkit-box-shadow: 0 1px 4px rgba(0,0,0,.2);
-moz-box-shadow: 0 1px 4px rgba(0,0,0,.2);
-o-box-shadow: 0 1px 4px rgba(0,0,0,.2);
box-shadow: 0 1px 4px rgba(0,0,0,.2);
zoom: 1;
border: 10px solid #fff;
padding-bottom: 40px;

display: inline-block;
width: 98%;
min-height:170px;
max-height:170px;
height:170px;
}

.flexslider .slides img
{
width: 100%;
display: block;
min-height:130px;
max-height:130px;
height:130px;
}

@media only screen and (min-width:481px)
{
.flexslider
{
width: 75%;
display: inline-block;
max-height:300px;
min-height:300px;
height:300px;
}

.flexslider .slides img
{
width: 100%;
display: block;
min-height:260px;
max-height:260px;
height:260px;
}
}

@media only screen and (min-width:769px)
{
.flexslider
{
width: 75%;
display: inline-block;
max-height:370px;
min-height:370px;
height:370px;
}

.flexslider .slides img
{
width: 100%;
display: block;
min-height:330px;
max-height:330px;
height:330px;
}
}

body										{line-height:1.2; font-size:80%; min-width:auto;}

</style>
</head>
<body style="margin:0 0 0 0; max-width:100%; min-width:100%;">

    <form method="post" action="hoteldetails.aspx?bid=41312d5444325753%2407d7e60eef16adc0055319c7dadae8ec" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="7Spfbi8HTTIRWYmHfeQVa1GKz2VVawJ12btyJOBX9YglOBaaT5EYxwkqp4XBOweOmMjIVwo9CwZYMf01Of+bVRpLWln8NWk0H7se6l4R8tagHkwE9KyN7hqeqkBlRqcvzvbrcqQXCgFrvYQzR5U3jVZeNwOvl8/RdCn1aKSJyaka1DweGFpbFg4S82fIyikGOCKuhreFrb3ar79kcEhJbafFwym+kmOHd/drvKlUFHz3AB5KjLROpEUNy3jBhMEPmaj2YEJjtLBNTwayk7qDpfpNwSLOR/twO8jAltiJtkrO/DgHftMiR56PNrLDkBFpdiqjlZhF1HWW58MxEx6vj6ICEbShn88W6LqzNHsEyEg4QNv/W4WSdmBsAZFOh/SSez6BvNfwyxHQdX3coKDMJF9GVZDhzJX1ZYYvxVb9SEWzLOI9Ey4FGsnDUQNbbv10jmsrxJGrz9Hy8b5Kxa6Ug58FOsT1/50PDCaZVeJbazvFimY/fDFd1OvdE/6NB4uno5tcXhC/kDhuVgv/oKIby0e1/M2IWqfMapClrc9ASttfdHtBPZk8us8RihBp2IJ8zEvzyqsfE8+cTSOnJ6WsXSg4QXVDQgk/Su2aV1Cp0dHU/CT2lf9PGvZp7zivVRQ5vyNIS9jDZyC1J3T17MtxV8Agx6Zpx1M4SMt9z3+jqYusnQVWq3o68+oXNdw77oHQ8VbR9weFyui1rbTribrQPME/6ctB+tb8extgOD+kfeuoXJJq9Bm4SXZ4oPMI1s3cVZontcVoIW1upBFXaHraSrfdHEsRdr/L3JOKJLGBG8jNMM1KZX79MotkCe0Xs3J6KPCGNoYJKIymrppj88YasRsCZ1KdbFxn6EicUcFwm3HcW3WYOELbGPD6E0Tl1zvg/64XUSagwAe2Z0NPDAJ4PSQ+NDXNMoJnvh2qbnmmsY+R45n43bqZcbxSXJ/KR+DjhHmifDYojVQbpIaGnErLrFk0ZyeQA4GcIIeoXcsHPSsVyTVzYdKNrMFX7FRlO7mFwYh51+XdH3rq1wIouyAzSWVYbr+4t7j79waZtHQvb5NdjXOBN/GXnb/RfDk0omV4sK7k+wWXeSyRsCAuFW2UDsA4LUQD9/dCmWmYkroTp82dZnxYmLybgY42mcoDWfXvC2qmTZAFjZXPjF0VIs7Dxn/DH8h9IWCDmuaKrWT0twBaD8LIRs0dKDDn2pdgbCYmvPBwsle4tPHouRwA7+mm0wo6iKeWrgYrKaXw8n4drPVBbh60Lk4xqpZOG1msbNCtwmlSRXibu3uswamhHxU7AhY2X36V6YDCAiWp9Vew5VLK4R5sJsrP/V0eATutGBAvun6+LxUK0Awj0pGZ2REzgIi1uhpssgW6dJxhLfCJJ2fRIzr/XZfDx0XyqvzKJJhRdhc3Ygj5gVd6CtbIGJJ1RvnMlzZbz8N+SzFCuzNq9jBhOP1BFMSa1IZYAsMl42ap1ftl4XHd9RYooAMrDA8WwvwP8qsMMjm7/MzcrZycloOkufeLdTT3L3oGxm5TIRx9M+dKv5a3Bhk99kTO4Xfm20WAoH6Q/fgzIJzN0aXLQBk+88zan1R9yT6knXHYzafj/9klI+kBEla1E2UeaBtEUI0ktLvKvQpgthDxpdxSgRQqgAT8Fzl5D6j95iHxH16d5REg98/fwiE6C5XIXzeoG7HmLr2jFmCyK3ECGg+BA9AZduDW3oqNRgKyarjHWeycpBD5WGUnaQMMPEGKfWK/NjjJf0eTD70N/DJc+wlLgcqsSPJEX957PaG+AwRwfJjndBUNmIw12f0IoShmNcBSx+AVuJqdtJ28dHI1TbmW6wV/05gZKYJgbOQaBS70hl+nQog2TaRmbuXjt0NAxY4NQ9eMRgviLXbFbuBe9W79RFDZyvSZQuLbZMAIS4HbG7SrUxXCsuKhbHbCocXrcJ2vngISoOQ+Xc8d2xFtTCHSJmh0RSQC9sEEyKyl4Ak5vXQzJ9N8T6GOBgExpa8GZnDfob+3cgpCnTsUVBq2XwmjsHru4VrcTBHO1BvXeXQIrb1xARR9/8i2ID3ygtNnxjprFZDb/ZB9+xpPYhAMKN2DSNxqtZmP5Yu7lhhSazQCC+1zGi++URjl63RQ+AOO4vUFMlf/tsygcsRqSfue8R3gfZOmA43SvUAORWYO7A+5FbzlG/Hmx1szYLfo0NcPD364bmGxI2fRF0FdBLv4pHaClx+Udi+X/Cx8OkVc17hVhlJ03B8B9uBH8BAaY5HTXyDDwJuTC3ORaTCwGhOpLLANiQ9BuSNU9ZdHJPb2tu7hQ2nY2Q7GPPOnXsxgbeTH8YJALdw1SXyS6faAFi4MkIM/8Abunf5kVmyx8rT7y0TZw1ZVbsF+XnPdJj/h/JhHY/R6+p5JZDcqCerMA6LJbGZEQXTczVnkNLlBtHc/34kwl8MyXUMFPiockyPCIbK5sPuQHRVC8/E5dDmARUChfY7oPDU5yrTXMqJF3VGtVQ41uiQ5oV/5iVa8O7yhMphOWqdYniTSyping934SPGj6HjCmMBu/0VF8FWEugqxgaCpmKm+O5UC1Z5QA0YMxOm8FotA14oTShZcEu/9wcI4SU5h+iZNu/sI8SFcxmx4GoZnNFxcHx3yLDg6hXGN3Ur83zAGPhKqa2ilEiZ5ZAx5FFxpoUudlPPtQC6LwN9BjA8DX0goT7sOmyMUCyJ7FRJQ1Hjxxs+2jXGr+HxHRCE5zl3qXU3qspaLt48xRvnY5EekSDssvPK87Qiw/MvrUAEJTWfRKLYgvUNZzM4Q1PiXbzJ1SzjQZK8KFTivGxmzwM4+rSmiJCj/lVeIGbYYVrOLj65GcbOqFU4mc6NNcNaJM6r63QKPFjuIB9rhnXtarga4s8u/ZYS9IArOoWBRtJgylzp+yOLyhy4G1a/Fr6q/H8vDoTqrNeQWTeC6VjPZthC1z6v/0EoAdKi0NZqGts9El6V+nSWO6YtItqJqxPkFOZyqRUk5a6DDJKbsdfJXfJ28xCUEan9MQTFRlhbVeB0DHNIecfhAeKtpjhvI2q+AuNkU0y6E2zg8bm1ZelTVXG65g4CrI557u1IWThI4p2G60G7BqLw4+byYYQSWIZ9DpsjV2XIPICyEF0FshmPxo/qmifUaFXahfhOpa1qscoWOrHAe27M2X3cLJSmMHJLNBv7QPQuE9xD6D6UMMp+TyFWqh9mBwg17Df7DsdgaZsBslKlNIBezj81gGjrRb2msuv1CKtfNryTpwfDSvyTUY/bGpTFA1tNT0eqlJavJ9xSM7L/nlNlElqsPX5fkGvCGlmrr5QDM+GAgQne5IQh/al25L71MtU0OSHbG1WNJXZk64IrKFrML0dAh/s8aNkgWxLh3Vka3n3KmzQkMwI9BTac5FJl8EBoN9/IOVOg+Fnr4mRx1wJc+M00mQWdzncNvgGFBi2vHP20qk8frLcxIi+mjdABJQesTRsqW3345zyo6+sCYJL+0WO7gs7k0SPttnTcduqVxxDM+WBEaWmZ6npL3zCP6KuYrCBuHfYHinpCLxXo1kxxt0yguBGLejl+0kraNnCrcDh42nvNmUHYKcDQPD1E+" />
</div>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="0CFD3419" />
</div>

        <!--DESCRIPTION-->
        <div class="bg_grey padded center">
            <div class="has_bottom_margin">
               
                <h3>
                    <strong>
                        <span id="lblHName"><?php echo urldecode($result['HotelName']);?></span>
                    </strong></h3>
                <h4 class="txt_color_1">                    
                    <span id="lblRegion"><?php echo urldecode($result['Resort']);?></span>                   
                </h4>
            </div>
            <!--IMAGES-->
            <div class="flexslider">
                <ul class="slides">
               
                  <?php  
                  if(count($result['Images']['Url']) == 1)
                  {
                  	echo '<li>';
                  	echo '<img src="'.urldecode($result['Images']['Url']).'" />';
                  	echo '</li>';
                  }else if(count($result['Images']['Url']) > 1)
                  {
                  	
                  	foreach($result['Images']['Url'] as $url){
                  		echo '<li>';
                  		echo '<img src="'.urldecode($url).'" />';
                  		echo '</li>';
                  	}
                  }                 
                  else
                  {
                  	echo '<li>';
                  	echo '<img src="default-image.png" />';
                  	echo '</li>';
                  }
                  ?>                        
                    <!-- items mirrored twice, total of 12 -->
                </ul>
            </div>
            <!--IMAGES-->
            <p>
                <span id="lblHDesc"><?php echo urldecode($result['HotelDescription']);?></span>
            </p>
            
        </div>
        <!--/DESCRIPTION-->

        <script>
            // Can also be used with $(document).ready()
            $(window).load(function () {
                $('.flexslider').flexslider({
                    animation: "slide",
                    animationLoop: true,

                    itemMargin: 5,
                    minItems: 1,
                    maxItems: 10
                });
            });

        </script>

    </form>
</body>
</html>
