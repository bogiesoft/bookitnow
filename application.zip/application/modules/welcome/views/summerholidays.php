
<div id="body_content">
<div class="container">

<div class="col-sm-9" style="padding-left:0px;">
<div class="about">
<div class="title"> Summer Holidays </div>
<div class="contactform">  
      <img src="http://superescapes.co.uk/CityImages/Summerholidays.jpg" width:"750px"="" height:"250px"="" alt="Cheap Holidays">  
<p>Summer holidays have arrived! Kids are out of school, and everybody wants to recharge themselves. Plan your great summer holidays with super escapes to the sun-kissed beaches to spend the special time with your family that you have dreamt of. Whether you want to spend long, lazy days relaxing on the warm sunny sands, want to enjoy fun filled activities with your kids or looking to enjoy the beautiful landscapes, We have a wonderful range of cheap summer holiday deals to numerous family holiday destinations that suit your budget. The all inclusive summer deal would be the best bargain to escape at the last minute. The complete entertainment for your family that will long last in your memories. Check out our best and budget friendly family holiday destinations.</p>
	

        
    </div>


</div>










</div>


<!--sidebar-->
    <div class="col-sm-3">
        <div class="left-sidebar">
       <?php include_once 'includes/atol_left.php';?>
	<?php include_once 'includes/news_letter_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/independent_reviews_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/deals_email_left.php';?>

</div>
</div>
<!--sidebar-->

</div>
</div>

