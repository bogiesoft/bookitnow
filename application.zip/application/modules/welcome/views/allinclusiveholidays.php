
<div id="body_content">
<div class="container">

<div class="col-sm-9" style="padding-left:0px;">
<div class="about">
<div class="title"> All Inclusive Holidays </div>
	<div class="contactform">  
      <img src="http://superescapes.co.uk/CityImages/All-inclusive-holidays2016.jpg" width:"750px"="" height:"250px"="" alt="Cheap Holidays">  
		<p>All Inclusive holidays have become very popular among the holiday makers. As the name itself tells, you will have almost everything covered including your flights, hotel, food and entertainment activities.
Our cheap all inclusive package holidays allow you to save on your wallet and spend on your family making the most of your holiday. </p>
 	</div>
</div>










</div>


<!--sidebar-->
    <div class="col-sm-3">
        <div class="left-sidebar">
       <?php include_once 'includes/atol_left.php';?>
	<?php include_once 'includes/news_letter_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/independent_reviews_left.php';?>
	<div class="clearfix"></div>
	<?php include_once 'includes/deals_email_left.php';?>

</div>
</div>
<!--sidebar-->

</div>
</div>

