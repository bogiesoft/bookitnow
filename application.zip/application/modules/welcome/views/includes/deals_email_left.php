<!-- <div class="deals">
<h2>Deals By Email</h2>
<ul>
<li><i class="fa fa-chevron-right"></i> &nbsp;<a href="#">Exclusive Holiday Deals</a></li>
<li><i class="fa fa-chevron-right"></i> &nbsp;<a href="#">Competitions and Giveaways</a></li>
<li><i class="fa fa-chevron-right"></i> &nbsp;<a href="#">Discount Vouchers</a></li>
</ul>

<p>Holiday deals &amp; discounts delivered direct to your inbox</p>
<div class="register"><a href="#">REGISTER FREE</a></div>


</div>-->