<div class="reviews">
<h2>Independent Reviews</h2>
<p>We are dedicated towards delivering our best in quality and service. Read what our customer says about superescapes on feefo.</p>

<div class="review" style="float:left"><img src="<?php echo base_url();?>images/feefo-logo.png" class="img-responsive"></div>
</div>