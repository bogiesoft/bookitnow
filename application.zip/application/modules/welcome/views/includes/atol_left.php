<div class="superescapes">
<h2>Why Book It Now Travel?</h2>
<ul>
<li><img src="<?php echo base_url();?>images/1.png"><a href="#">ATOL holders</a></li>
<li><img src="<?php echo base_url();?>images/2.png"><a href="#">ATOL Protected</a></li>
<li><img src="<?php echo base_url();?>images/3.png"><a href="#">Hand picked deals</a></li>

</ul>

</div>