
<div id="wrapper">
<!--top header start-------->
<div class="top_bg">
  <div class="container">
    <div class="row">
      <div class="top_left">
        <ul>
          <li class="top_link"><a href="<?php echo base_url();?>">Home </a></li>
       	  <li class="top_link"><a href="<?php echo base_url();?>admin/logout">Logout</a></li>
        </ul>
      </div>
      
    </div>
  </div>
</div>
<!--top header end--------> 

<!--header top start-------->


<div class="header_top">
  <div class="container">
    <div class="row">
     
    </div>
  </div>
</div>

<div class="clearfix"> </div>
<!--header top end-------->

<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <div class="login">
        <h1>Dashboard</h1>
        <div class="login-bottom">
          
          <div class="social-icons">
           <div class="col-sm-12">
        <div class="logo" ><a href="#"><img src="<?php echo base_url();?>images/logo.png" ></a></div>
      </div>
      <div class="clearfix"></div>
    </div>   
    	
      </div>
    </div>
  </div>
  <div class="clearfix"></div>
  </div>
</div>

